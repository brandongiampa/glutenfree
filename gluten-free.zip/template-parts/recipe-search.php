<form action="<?php echo $_SERVER[ 'PHP_SELF' ]; ?>">
    <?php if ( isset( $_GET[ 'c' ] ) ) {
        echo $_GET[ 'c' ];
    } ?>
</form>