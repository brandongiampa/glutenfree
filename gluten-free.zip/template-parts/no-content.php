<div class="container">
    <h1>Uh-oh!</h1>
    <p>The content you are looking for either has moved or did not exist in the first place.</p>
</div>