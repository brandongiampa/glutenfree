import { _sortPropTweensByPriority } from "gsap/gsap-core"


const { registerBlockType } = wp.blocks
const { __ } = wp.i18n
const el = element.createElement
const { InspectorControls } = wp.blockEditor
const { PanelBody, PanelRow, TextControl, SelectControl, __experimentalNumberControl, ToggleControl, withState
 } = wp.components

const selectOptions = Object.keys( glfr_wp.post_categories ).map( function ( value ) {
    return { value: glfr_wp.post_categories[ value ].name, label: glfr_wp.post_categories[ value ].name }
} )

registerBlockType( 'glfr/latest-gfb-posts', {
    title:          __( 'GFB Latest Posts', 'glfr' ),
    description:    __( 
        'Provides a list of latest posts that links to post when clicked ANYWHERE',
        'glfr'
    ),
    category:       'common',
    icon:           "index-card",
    keywords:       [
        __( "latest", "glfr" ),
        __( "recent", "glfr" ),
        __( "post", "glfr" ),
        __( "blog", "glfr" ),
        __( "recipe", "glfr" )
    ],
    supports:       {
        html:       false 
    },
    attributes: {

        selectedCategory: {
            type: 'string',
            default: "All",
            // source: "text",
            selector: '.glfr-recent-posts'
        },

        selectOptions: {
            type: 'array',
            // default: selectOptions
            default: [ 'All' ]
        },

        recentPosts: {
            default: 
                glfr_wp.recent_posts.filter( ( entry ) => {
                    return entry.category === 'All'
                } ),
            type: 'array',
            selector: '.glfr-recent-posts'
        },

        numberOfPosts: {
            type: 'integer',
            source: "text",
            default: 4,
            selector: '.glfr-number-of-posts'
        },

        showThumbnail: {
            type: 'boolean',
            default: true
        },

        showAuthor: {
            type: 'boolean',
            default: true
        },

        showExcerpt: {
            type: 'boolean',
            default: true
        }

    },

    edit:           ( props ) => {
        return [
            <InspectorControls>
                <PanelBody title={ __( 'Basics', 'glfr' ) }>
                    <PanelRow>
                        <p>{ __( 'Configure the contents of your block here.', 'glfr' ) }</p>
                    </PanelRow>
                    <__experimentalNumberControl
                        label={ __( 'Number of Posts:', 'glfr' ) }
                        value={ props.attributes.numberOfPosts }
                        onChange={ ( new_val ) => {
                            if( new_val > 8 ){
                                alert( "The maximum number of recent posts allowed is 8." )
                                props.setAttributes( { numberOfPosts: 8 } )
                            }
                            else if ( new_val < 1 ) {
                                alert( "There must be at least one post listed." )
                                props.setAttributes( { numberOfPosts: 1 } )
                            }
                            else {
                                props.setAttributes( { numberOfPosts: new_val } )
                                props.setAttributes( { recentPosts: glfr_wp.recent_posts.filter( ( entry ) => {
                                    return entry.category === props.attributes.selectedCategory
                                } ) } )
                            }
                        } }
                    />
                    <SelectControl 
                        label={ __( 'Category:', 'glfr' ) }
                        help= { __( "Blogs, News, etc." , 'glfr' ) }
                        value={ props.attributes.selectedCategory }
                        options={ [ { value: "All", label: "All" }, ...selectOptions ] }
                        onChange={ ( new_val ) => {
                            
                            props.setAttributes( { selectedCategory: new_val } ) 
                            props.setAttributes( { recentPosts: glfr_wp.recent_posts.filter( ( entry ) => {
                                return entry.category === new_val
                            } ) } )

                            // console.log( props.attributes.selectedCategory )
                            // console.log( props.attributes.recentPosts )
                        } }
                    />
                </PanelBody>
                <PanelBody title={ __( 'Options', 'glfr' ) }>
                    <ToggleControl
                        label="Show Thumbnail"
                        help={ props.attributes.showThumbnail ? 'Show custom thumbnail of post.' : 'Hide custom thumbnail of post.' }
                        checked={ props.attributes.showThumbnail }
                        onChange={ ( new_val ) => props.setAttributes( { showThumbnail: new_val } ) }
                    />
                    <ToggleControl
                        label="Show Author"
                        help={ props.attributes.showAuthor ? 'Show post author\'s name.' : 'Hide post author\'s name.' }
                        checked={ props.attributes.showAuthor }
                        onChange={ ( new_val ) => props.setAttributes( { showAuthor: new_val } ) }
                    />
                    <ToggleControl
                        label="Show Excerpt"
                        help={ props.attributes.showExcerpt ? 'Show excerpt of post.' : 'Hide excerpt of post.' }
                        checked={ props.attributes.showExcerpt }
                        onChange={ ( new_val ) => props.setAttributes( { showExcerpt: new_val } ) }
                    />
                </PanelBody>
            </InspectorControls>,
            <ul className={ "glfr-block-latest-posts " + props.attributes.className }>
                {
                    props.attributes.recentPosts.filter( ( value, index ) => {
                        return index < props.attributes.numberOfPosts
                    } ).map( ( value, index ) => {
                        return (
                        <li key={ index }>
                            <a href={ value.url }>
                                <div className="d-flex flex-column">
                                    {
                                        props.attributes.showThumbnail === true && 
                                        <div className="wp-block-latest-posts__featured-image aligncenter">
                                            <img src={ value.thumbnail }></img>
                                        </div>
                                    }
                                    <div className="post_title">
                                        { value.title }
                                    </div>
                                    {
                                        props.attributes.showAuthor === true && 
                                        <div className="wp-block-latest-posts__post-author">
                                            { value.author }
                                        </div>
                                    }
                                    {
                                        props.attributes.showExcerpt === true && 
                                        <div className="wp-block-latest-posts__post-excerpt">
                                            { value.excerpt }
                                        </div>
                                    }
                                </div>
                            </a>
                        </li>
                        )
                    })
                }
            </ul>
        ]
    },
    save:           ( props ) => {
        let i = 0
        return (
            <ul className={ "glfr-block-latest-posts" + props.attributes.className }>
                {
                    props.attributes.recentPosts.filter( ( value, index ) => {
                        return index < props.attributes.numberOfPosts
                    } ).map( ( value, index ) => {
                        return (
                        <li key={ index }>
                            <a href={ value.url }>
                                <div className="d-flex flex-column">
                                    {
                                        props.attributes.showThumbnail === true && 
                                        <div className="wp-block-latest-posts__featured-image aligncenter">
                                            <img src={ value.thumbnail }></img>
                                        </div>
                                    }
                                    <div className="post_title">
                                        { value.title }
                                    </div>
                                    {
                                        props.attributes.showAuthor === true && 
                                        <div className="wp-block-latest-posts__post-author">
                                            { value.author }
                                        </div>
                                    }
                                    {
                                        props.attributes.showExcerpt === true && 
                                        <div className="wp-block-latest-posts__post-excerpt">
                                            { value.excerpt }
                                        </div>
                                    }
                                </div>
                            </a>
                        </li>
                        )
                    })
                }
            </ul>
        ) 
    }
} )