const { registerBlockType } = wp.blocks
const { __ } = wp.i18n
const el = element.createElement
const { InspectorControls } = wp.blockEditor
const { PanelBody, PanelRow, TextControl, SelectControl, __experimentalNumberControl } = wp.components



import LatestPosts from './blocks/latest-posts'

// console.log( "Categories: " )
// console.log( glfr_wp.post_categories )
// console.log( "Recent Posts: "  )
// console.log( glfr_wp.recent_posts )
