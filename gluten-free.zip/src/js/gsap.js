import { gsap } from "gsap"
import ScrollTrigger from "gsap/ScrollTrigger"

gsap.registerPlugin( ScrollTrigger )

glfrFadeIn( "body" )
glfrFadeIn( "#branding", "header" )

document.querySelector( "#modal-trigger-div" ).length === null ? false : gsap.from( "#modal-trigger-div", {
    bottom: "-50%",
    opacity: 0,
    scale: 0,
    duration: 1.8,
    delay: 3
})

function glfrFadeIn( el, trigger = el ) {

    if ( document.querySelectorAll( el ) !== null ) {

        gsap.from( el, {
            scrollTrigger: {
                trigger: trigger
            },
            opacity: 0,
            duration: 1
        } )

    }

}