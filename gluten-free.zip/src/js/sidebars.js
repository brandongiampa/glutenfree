import $ from 'jquery'

const MODAL_TIME_SECONDS = 10000

const Sidebars = setTimeout( ()=> {
     $( ".modal-timed" ).modal( "show" )
}, MODAL_TIME_SECONDS )


export default Sidebars